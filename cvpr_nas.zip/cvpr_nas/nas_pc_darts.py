import numpy as np
import torch
import torch.nn as nn
import torch.utils
import torch.nn.functional as F
import torchvision.datasets as dset
import torch.backends.cudnn as cudnn

from torch.autograd import Variable
from pc_darts.utils import AvgrageMeter, accuracy
from pc_darts.model_search import Network
from pc_darts.architect import Architect
from pc_darts.model import NetworkCIFAR
import time
from datetime import timedelta

from RandAugment import RandAugment
import torchvision
from torchvision.transforms import transforms

class RandAugResnet(nn.Module):
    def __init__(self, model, transform, min_values, scale_values, input_size):
        super(RandAugResnet, self).__init__()
        self.model = model
        self.transform = transform
        self.device=torch.device('cuda') if torch.cuda.is_available() else torch.device("cpu")
        self.eval_transform = transforms.Compose([
            transforms.Normalize(min_values, scale_values),
            transforms.ToPILImage(),
            transforms.Resize((input_size,input_size)),
            transforms.ToTensor()
        ]) #32x32
        
    def forward(self, x):
        if self.training:
            xs = []
            for x_ in x:
                x_ = self.transform(x_)
                xs.append(x_)
            xs = torch.stack(xs)
            x = self.model(xs.to(self.device))
        else:
            xs = []
            for x_ in x:
                x_ = self.eval_transform(x_)
                xs.append(x_)
            xs = torch.stack(xs)
            x = self.model(xs.to(self.device))
        return x


class NAS:
    def __init__(self):
        pass

    def train(self, train_queue, valid_queue, model, architect, criterion, optimizer, lr, epoch):
      objs = AvgrageMeter()
      top1 = AvgrageMeter()
      top5 = AvgrageMeter()

      for step, (input, target) in enumerate(train_queue):
        model.train()
        n = input.size(0)
        input = Variable(input, requires_grad=False).cuda()
        target = Variable(target, requires_grad=False).long().cuda()

        # get a random minibatch from the search queue with replacement
        input_search, target_search = next(iter(valid_queue))
        #try:
        #  input_search, target_search = next(valid_queue_iter)
        #except:
        #  valid_queue_iter = iter(valid_queue)
        #  input_search, target_search = next(valid_queue_iter)
        input_search = Variable(input_search, requires_grad=False).cuda()
        target_search = Variable(target_search, requires_grad=False).long().cuda()

        if epoch>=9:
          architect.step(input, target, input_search, target_search, lr, optimizer, unrolled=False)

        optimizer.zero_grad()
        logits = model(input)
        loss = criterion(logits, target)

        loss.backward()
        nn.utils.clip_grad_norm(model.parameters(), 5)
        optimizer.step()

        prec1, prec5 = accuracy(logits, target, topk=(1, 5))
        objs.update(loss.item(), n)
        top1.update(prec1.item(), n)
        top5.update(prec5.item(), n)

      return top1.avg, objs.avg
    
    # given some input data, return the "best possible" architecture
    def search(self, train_x, train_y, valid_x, valid_y, metadata):
        n_classes = metadata['n_classes']
        batch_size = metadata['batch_size']
        lr = metadata['lr']
        momentum = 0.9
        weight_decay = 3e-4
        arch_lr = 6e-4
        epochs = 20
                
        channels = train_x.shape[1]
        min_values = []
        scale_values = []
        if train_x.shape[2] > train_x.shape[3]:
            input_size = train_x.shape[2] + 4
        else:
            input_size = train_x.shape[3] + 4
        for i in range(channels):
            min_values.append(np.min(train_x[:,i,:,:]))
            scale_values.append((np.max(train_x[:,i,:,:])-min_values[-1]))

        transform = transforms.Compose([
            transforms.Normalize(min_values, scale_values),
            transforms.ToPILImage(),
            transforms.Resize((input_size,input_size)),
            transforms.ToTensor()
        ]) #32x32
        
        train_dataset = torch.utils.data.TensorDataset(torch.Tensor(train_x), torch.Tensor(train_y).long())
        valid_dataset = torch.utils.data.TensorDataset(torch.Tensor(valid_x), torch.Tensor(valid_y).long())
        
        train_queue = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size*4)
        valid_queue = torch.utils.data.DataLoader(valid_dataset, batch_size=batch_size*4)

        criterion = nn.CrossEntropyLoss()
        criterion = criterion.cuda()
        model = Network(input_channel_num=train_x.shape[1],
                        C=8, 
                        num_classes=n_classes, 
                        layers=8, 
                        criterion=criterion)
        model = model.cuda()
        
        optimizer = torch.optim.SGD(
          model.parameters(),
          lr,
          momentum=momentum,
          weight_decay=weight_decay)
        
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, float(epochs), eta_min=0.08)
        
        architect = Architect(model, momentum, arch_lr, weight_decay)
        nas_start = time.time()
        for epoch in range(epochs):
            lr = scheduler.get_lr()[0]
            print ('epoch {} lr {}'.format(epoch, lr))

            genotype = model.genotype()
            print ('genotype = {}'.format(genotype))

            #print(F.softmax(model.alphas_normal, dim=-1))
            #print(F.softmax(model.alphas_reduce, dim=-1))

            # training
            train_acc, train_obj = self.train(train_queue, valid_queue, model, architect, criterion, optimizer, lr, epoch)
            
            print ('train_acc {}'.format(train_acc))
            scheduler.step()
            
            nas_end = time.time()
            print ('NAS elapsed: ', str(timedelta(seconds=(nas_end-nas_start))))
        
        final_genotype = model.genotype()
        del model
        if train_x.shape[1] == 1:
            final_model = NetworkCIFAR(train_x.shape[1], 16, n_classes, 9, False, final_genotype)
        else:
            final_model = NetworkCIFAR(train_x.shape[1], 36, n_classes, 9, False, final_genotype)
            
        transform.transforms.insert(3, RandAugment(2, 3))
        final_model = RandAugResnet(final_model, transform, min_values, scale_values, input_size)
        
        return final_model
    

test_i = -1

# load the exact data loaders that we'll use to load the data
from ingestion_program.nascomp.helpers import *

# load the exact retraining script we'll use to evaluate the found models
from ingestion_program.nascomp.torch_evaluator import *
# from ipywidgets import FloatProgress
# from ipywidgets import IntProgress

# if you want to use the real development data, download the public data and set data_dir appropriately
# data_dir = 'sample_data'
data_dir = 'data'


# find all the datasets in the given directory:
dataset_paths = get_dataset_paths(data_dir)
dataset_predictions = []
for i, path in enumerate(dataset_paths):
#     if i == test_i:
        (train_x, train_y), (valid_x, valid_y), (test_x), metadata = load_datasets(path)
        print("=== {} {}".format(metadata['name'],"="*50))
        print("Train X shape:",train_x.shape)
        print("Train Y shape:",train_y.shape)
        print("Valid X shape:",valid_x.shape)
        print("Valid Y shape:",valid_y.shape)
        print("Test X shape:", test_x.shape)
        print("Metadata:", metadata)


        # initialize our NAS class
        nas = NAS()

        # search for a model
        model = nas.search(train_x, train_y, valid_x, valid_y, metadata)

        # package data for the evaluator
        data = (train_x, train_y), (valid_x, valid_y), test_x

        # retrain the model from scratch
        results = torch_evaluator(model, data, metadata, n_epochs=64, full_train=True)

        # clean up the NAS class
        del nas

        # save our predictions
        dataset_predictions.append(results['test_predictions'])
    #     print(dataset_predictions)


overall_score = 0
out = []
for i, path in enumerate(dataset_paths):
#     if i == test_i:
        # load the reference values
        ref_y = np.load(os.path.join(path, 'test_y.npy'))

        # load the dataset_metadata for this dataset
        metadata =  load_dataset_metadata(path)

        print("=== Scoring {} ===".format(metadata['name']))
        index = metadata['name'][-1]

        # load the model predictions
        if test_i < 0:
            pred_y = dataset_predictions[i]
        else:
            pred_y = dataset_predictions[0]

        # compute accuracy
        score = sum(ref_y == pred_y)/float(len(ref_y)) * 100
        print("  Raw score:", score)
        print("  Benchmark:", metadata['benchmark'])

        # adjust score according to benchmark
        point_weighting = 10/(100 - metadata['benchmark'])
        score -= metadata['benchmark']
        score *= point_weighting
        print("  Adjusted:  ", score)

        # add per-dataset score to overall
        overall_score += score

        # add to scoring stringg
        out.append("Dataset_{}_Score: {:.3f}".format(index, score))
out.append("Overall_Score: {:.3f}".format(overall_score))

# print score
print(out)