import numpy as np
import torch
import torch.nn as nn
import torch.utils
import torch.nn.functional as F
import torchvision.datasets as dset
import torch.backends.cudnn as cudnn

from RandAugment import RandAugment
import torchvision
from torchvision.transforms import transforms
from shakeshake_models import ShakeResNet, ShakeResNeXt

class RandAugResnet(nn.Module):
    def __init__(self, model, transform, min_values, scale_values, input_size):
        super(RandAugResnet, self).__init__()
        self.model = model
        self.transform = transform
        self.device=torch.device('cuda') if torch.cuda.is_available() else torch.device("cpu")
        self.eval_transform = transforms.Compose([
            transforms.Normalize(min_values, scale_values),
            transforms.ToPILImage(),
            transforms.Resize((input_size,input_size)),
            transforms.ToTensor()
        ]) #32x32
        
    def forward(self, x):
        if self.training:
            xs = []
            for x_ in x:
                x_ = self.transform(x_)
                xs.append(x_)
            xs = torch.stack(xs)
            x = self.model(xs.to(self.device))
        else:
            xs = []
            for x_ in x:
                x_ = self.eval_transform(x_)
                xs.append(x_)
            xs = torch.stack(xs)
            x = self.model(xs.to(self.device))
        return x

class NAS:
    def __init__(self):
        pass

    def search(self, train_x, train_y, valid_x, valid_y, metadata):
        n_classes = metadata['n_classes']
        
        channels = train_x.shape[1]
        min_values = []
        scale_values = []
        if train_x.shape[2] > train_x.shape[3]:
            input_size = 64 + 4 #train_x.shape[2] + 4
        else:
            input_size = 64 + 4 #train_x.shape[3] + 4
        for i in range(channels):
            min_values.append(np.min(train_x[:,i,:,:]))
            scale_values.append((np.max(train_x[:,i,:,:])-min_values[-1]))

        transform = transforms.Compose([
            transforms.Normalize(min_values, scale_values),
            transforms.ToPILImage(),
            transforms.Resize((input_size,input_size)),
            transforms.ToTensor()
        ]) #32x32
    
        # Loading model
        model = ShakeResNet(26, 64, n_classes)
        model.c_in = nn.Conv2d(train_x.shape[1], model.in_chs[0], 3, padding=1)


        # Add RandAugment with N, M(hyperparameter)
        transform.transforms.insert(3, RandAugment(2, 3))
        model = RandAugResnet(model, transform, min_values, scale_values, input_size)
        
        return model

    
        
# load the exact data loaders that we'll use to load the data
from ingestion_program.nascomp.helpers import *

# load the exact retraining script we'll use to evaluate the found models
from ingestion_program.nascomp.torch_evaluator import *
# from ipywidgets import FloatProgress
# from ipywidgets import IntProgress

# if you want to use the real development data, download the public data and set data_dir appropriately
# data_dir = 'sample_data'
data_dir = 'data'


# find all the datasets in the given directory:
dataset_paths = get_dataset_paths(data_dir)
dataset_predictions = []
for i, path in enumerate(dataset_paths):
#     if i == 2:
        (train_x, train_y), (valid_x, valid_y), (test_x), metadata = load_datasets(path)
        print("=== {} {}".format(metadata['name'],"="*50))
        print("Train X shape:",train_x.shape)
        print("Train Y shape:",train_y.shape)
        print("Valid X shape:",valid_x.shape)
        print("Valid Y shape:",valid_y.shape)
        print("Test X shape:", test_x.shape)
        print("Metadata:", metadata)


        # initialize our NAS class
        nas = NAS()

        # search for a model
        model = nas.search(train_x, train_y, valid_x, valid_y, metadata)

        # package data for the evaluator
        data = (train_x, train_y), (valid_x, valid_y), test_x

        # retrain the model from scratch
        results = torch_evaluator(model, data, metadata, n_epochs=64, full_train=True)

        # clean up the NAS class
        del nas

        # save our predictions
        dataset_predictions.append(results['test_predictions'])
    #     print(dataset_predictions)


overall_score = 0
out = []
for i, path in enumerate(dataset_paths):
#     if i == 2:

        # load the reference values
        ref_y = np.load(os.path.join(path, 'test_y.npy'))

        # load the dataset_metadata for this dataset
        metadata =  load_dataset_metadata(path)

        print("=== Scoring {} ===".format(metadata['name']))
        index = metadata['name'][-1]

        # load the model predictions
        pred_y = dataset_predictions[i]
#         pred_y = dataset_predictions[0]

        # compute accuracy
        score = sum(ref_y == pred_y)/float(len(ref_y)) * 100
        print("  Raw score:", score)
        print("  Benchmark:", metadata['benchmark'])

        # adjust score according to benchmark
        point_weighting = 10/(100 - metadata['benchmark'])
        score -= metadata['benchmark']
        score *= point_weighting
        print("  Adjusted:  ", score)

        # add per-dataset score to overall
        overall_score += score

        # add to scoring stringg
        out.append("Dataset_{}_Score: {:.3f}".format(index, score))
out.append("Overall_Score: {:.3f}".format(overall_score))

# print score
print(out)