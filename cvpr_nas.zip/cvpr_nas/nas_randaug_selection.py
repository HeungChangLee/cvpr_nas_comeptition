import numpy as np
import torch
import torch.nn as nn
import torch.utils
import torch.nn.functional as F
import torchvision.datasets as dset
import torch.backends.cudnn as cudnn
from functools import partial
from torchvision.models.mobilenetv2 import ConvBNActivation

from RandAugment import RandAugment
import torchvision
from torchvision.transforms import transforms
from shakeshake_models import ShakeResNet, ShakeResNeXt
import io
from torch.autograd import Variable
from datetime import timedelta

class AvgrageMeter(object):

  def __init__(self):
    self.reset()

  def reset(self):
    self.avg = 0
    self.sum = 0
    self.cnt = 0

  def update(self, val, n=1):
    self.sum += val * n
    self.cnt += n
    self.avg = self.sum / self.cnt
    
def accuracy(output, target, topk=(1,)):
  maxk = max(topk)
  batch_size = target.size(0)

  _, pred = output.topk(maxk, 1, True, True)
  pred = pred.t()
  correct = pred.eq(target.view(1, -1).expand_as(pred))

  res = []
  for k in topk:
#     print(correct[:k].float().sum(0))
#     correct_k = correct[:k].view(-1).float().sum(0)
    correct_k = correct[:k].float().sum()
#     print(correct_k)
    res.append(correct_k.mul_(100.0/batch_size))
  return res
    
class RandAugResnet(nn.Module):
    def __init__(self, model, transform, min_values, scale_values, input_size):
        super(RandAugResnet, self).__init__()
        self.model = model
        self.transform = transform
        self.device=torch.device('cuda') if torch.cuda.is_available() else torch.device("cpu")
        self.eval_transform = transforms.Compose([
            transforms.Normalize(min_values, scale_values),
            transforms.ToPILImage(),
            transforms.Resize((input_size,input_size)),
            transforms.ToTensor()
        ])
        
    def forward(self, x):
        if self.training:
            xs = []
            for x_ in x:
                x_ = self.transform(x_)
                xs.append(x_)
            xs = torch.stack(xs)
            x = self.model(xs.to(self.device))
        else:
            xs = []
            for x_ in x:
                x_ = self.eval_transform(x_)
                xs.append(x_)
            xs = torch.stack(xs)
            x = self.model(xs.to(self.device))
        return x

class NAS:
    def __init__(self):
        pass

    def search(self, train_x, train_y, valid_x, valid_y, metadata):
        n_classes = metadata['n_classes']
        batch_size = metadata['batch_size']
        lr = metadata['lr']
        momentum = 0.9
        weight_decay = 3e-4
        epochs = 10
        acc_list = []
        loss_list = []
        channels = train_x.shape[1]
        min_values = []
        scale_values = []
        if train_x.shape[2] > train_x.shape[3]:
            input_size = 64 + 4#train_x.shape[2] + 4
        else:
            input_size = 64 + 4#train_x.shape[3] + 4
        for i in range(channels):
            min_values.append(np.min(train_x[:,i,:,:]))
            scale_values.append((np.max(train_x[:,i,:,:])-min_values[-1]))
        
        train_dataset = torch.utils.data.TensorDataset(torch.Tensor(train_x), torch.Tensor(train_y).long())
        valid_dataset = torch.utils.data.TensorDataset(torch.Tensor(valid_x), torch.Tensor(valid_y).long())
        
        train_queue = torch.utils.data.DataLoader(train_dataset, batch_size=batch_size*20)
        valid_queue = torch.utils.data.DataLoader(valid_dataset, batch_size=batch_size*20)

        criterion = nn.CrossEntropyLoss()
        criterion = criterion.cuda()
        ## MobileNet V3 Large
        model = torchvision.models.mobilenet_v3_large()
        norm_layer = partial(nn.BatchNorm2d, eps=0.001, momentum=0.01)
        model.features[0] = ConvBNActivation(64, 16, kernel_size=3, stride=2, norm_layer=norm_layer,
                                       activation_layer=nn.Hardswish)
        model.classifier = nn.Sequential(
            nn.Linear(960, 1280),
            nn.Hardswish(inplace=True),
            nn.Dropout(p=0.2, inplace=True),
            nn.Linear(1280, n_classes),
        )
        model = nn.Sequential(
            nn.Conv2d(train_x.shape[1], 64, kernel_size=(7, 7), stride=1, padding=3),
            norm_layer(64),
            nn.ReLU(inplace=True),
            model
        )
        model = model.cuda()
        
        transform = transforms.Compose([
            transforms.Normalize(min_values, scale_values),
            transforms.ToPILImage(),
            transforms.Resize((input_size,input_size)),
            transforms.ToTensor()
        ])

        # Add RandAugment with N, M(hyperparameter)
        rand_aug = RandAugment(1,3)
        transform.transforms.insert(3, rand_aug)
        model = RandAugResnet(model, transform, min_values, scale_values, input_size)
        
        
#         optimizer = torch.optim.SGD(
#           model.parameters(),
#           lr,
#           momentum=momentum,
#           weight_decay=weight_decay)
        
#         scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
#             optimizer, float(epochs), eta_min=0.0)
        
        saved_lottery = torch.save(model.state_dict(), 'tmp_model1.pt')
        nas_start = time.time()
        for i in range(rand_aug.aug_num):
            rand_aug.sample([i])
            print(rand_aug.aug_class.augment_list())
            
            lr = 1e-3
            momentum = 0.9
            weight_decay = 3e-4
            model.load_state_dict(torch.load('tmp_model1.pt'))
            
            #SGD
            optimizer = torch.optim.SGD(
              model.parameters(),
              lr,
              momentum=momentum,
              weight_decay=weight_decay)

            scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
                optimizer, float(epochs), eta_min=0.0)

            #Adam
#             optimizer = torch.optim.Adam(
#               model.parameters(),
#               lr,
#               weight_decay=weight_decay)
            
            for epoch in range(epochs):
                objs = AvgrageMeter()
                val_loss = AvgrageMeter()
                top1 = AvgrageMeter()
                cur_lr = scheduler.get_last_lr()[0] #get_lr()[0]
#                 for param_group in optimizer.param_groups:
#                     cur_lr = param_group['lr']
                print ('epoch {} lr {}'.format(epoch, cur_lr))
                # training
                model.train()

                for step, (input, target) in enumerate(train_queue):
                    input = Variable(input).cuda()
                    target = Variable(target).cuda()

                    optimizer.zero_grad()
                    logits = model(input)
                    loss = criterion(logits, target)
                    loss.backward()
                    optimizer.step()

                    n = input.size(0)
                    objs.update(loss.item(), n)
#                     optimizer.step()

                model.eval()
  
                with torch.no_grad():
                    for step, (input, target) in enumerate(valid_queue):
                      input = Variable(input).cuda()
                      target = Variable(target).cuda()

                      logits = model(input)
                      loss = criterion(logits, target)
                      
                      prec1, _ = accuracy(logits, target, topk=(1, 5))
                      n = input.size(0)
                      val_loss.update(loss.item(),n)
                      top1.update(prec1.item(), n)
                
                print ('train_loss: {:.3f}, valid_loss: {:.3f}, valid_acc: {:.3f}'.format(objs.avg, val_loss.avg, top1.avg))
                scheduler.step()
            
            print ('done train, train_loss: {:.3f}, valid_loss: {:.3f}, valid_acc: {:.3f}'.format(objs.avg, val_loss.avg, top1.avg))
            loss_list.append(objs.avg)
            acc_list.append(top1.avg)
        nas_end = time.time()
        print ('NAS elapsed: ', str(timedelta(seconds=(nas_end-nas_start))))
        print(acc_list)
        
        x = np.array(acc_list)
        rank_acc = np.argsort(x)[-5:]
        
        del model
        # Loading model       
        model = ShakeResNet(input_size, 64, n_classes)
        modules = []
        cnt = round(input_size/32)
        
        for i in range(cnt):
            if i == 0:
                modules.append(nn.Conv2d(train_x.shape[1], model.in_chs[0], 3, padding=1))
            else:
                modules.append(nn.ReLU(inplace=False))
                modules.append(nn.Conv2d(model.in_chs[0], model.in_chs[0], 3, 2, padding=1))

        model.c_in = nn.Sequential(*modules)

        # Add RandAugment with N, M(hyperparameter)
        rand_aug = RandAugment(2,3)
        rand_aug.sample(rank_acc.tolist())
        transform.transforms.insert(3, rand_aug)
#         transform.transforms.insert(3, RandAugment(2, 3))
        model = RandAugResnet(model, transform, min_values, scale_values, input_size)
        
        return model

        
# load the exact data loaders that we'll use to load the data
from ingestion_program.nascomp.helpers import *

# load the exact retraining script we'll use to evaluate the found models
from ingestion_program.nascomp.torch_evaluator import *
# from ipywidgets import FloatProgress
# from ipywidgets import IntProgress

# if you want to use the real development data, download the public data and set data_dir appropriately
# data_dir = 'sample_data'
data_dir = 'data'


# find all the datasets in the given directory:
dataset_paths = get_dataset_paths(data_dir)
dataset_predictions = []
for i, path in enumerate(dataset_paths):
#     if i == 2:
        (train_x, train_y), (valid_x, valid_y), (test_x), metadata = load_datasets(path)
        print("=== {} {}".format(metadata['name'],"="*50))
        print("Train X shape:",train_x.shape)
        print("Train Y shape:",train_y.shape)
        print("Valid X shape:",valid_x.shape)
        print("Valid Y shape:",valid_y.shape)
        print("Test X shape:", test_x.shape)
        print("Metadata:", metadata)


        # initialize our NAS class
        nas = NAS()

        # search for a model
        model = nas.search(train_x, train_y, valid_x, valid_y, metadata)

        # package data for the evaluator
        data = (train_x, train_y), (valid_x, valid_y), test_x

        # retrain the model from scratch
        results = torch_evaluator(model, data, metadata, n_epochs=64, full_train=True)

        # clean up the NAS class
        del nas

        # save our predictions
        dataset_predictions.append(results['test_predictions'])
    #     print(dataset_predictions)


overall_score = 0
out = []
for i, path in enumerate(dataset_paths):
#     if i == 2:

        # load the reference values
        ref_y = np.load(os.path.join(path, 'test_y.npy'))

        # load the dataset_metadata for this dataset
        metadata =  load_dataset_metadata(path)

        print("=== Scoring {} ===".format(metadata['name']))
        index = metadata['name'][-1]

        # load the model predictions
        pred_y = dataset_predictions[i]
#         pred_y = dataset_predictions[0]

        # compute accuracy
        score = sum(ref_y == pred_y)/float(len(ref_y)) * 100
        print("  Raw score:", score)
        print("  Benchmark:", metadata['benchmark'])

        # adjust score according to benchmark
        point_weighting = 10/(100 - metadata['benchmark'])
        score -= metadata['benchmark']
        score *= point_weighting
        print("  Adjusted:  ", score)

        # add per-dataset score to overall
        overall_score += score

        # add to scoring stringg
        out.append("Dataset_{}_Score: {:.3f}".format(index, score))
out.append("Overall_Score: {:.3f}".format(overall_score))

# print score
print(out)