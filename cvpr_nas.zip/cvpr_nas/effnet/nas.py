from .model import EfficientNet, VALID_MODELS
# from .utils import (
#     GlobalParams,
#     BlockArgs,
#     BlockDecoder,
#     efficientnet,
#     get_model_params,
# )
import torch.nn as nn

class NAS:
    def __init__(self):
        pass
    
    def search(self, train_x, train_y, valid_x, valid_y, metadata):
        n_classes = metadata['n_classes']
#         model = EfficientNet.from_pretrained('efficientnet-b1', num_classes=n_classes)
        model = EfficientNet.from_name('efficientnet-b1', in_channels=train_x.shape[1], num_classes=n_classes)

        return model
        