import numpy as np
import torch
import torch.nn as nn
import torch.utils
import torch.nn.functional as F
import torchvision.datasets as dset
import torch.backends.cudnn as cudnn

from RandAugment import RandAugment
import torchvision
from torchvision.transforms import transforms
from shakeshake_models import ShakeResNet, ShakeResNeXt
from torch.autograd import Variable

def mixup_data(x, y, alpha=1.0, use_cuda=True):
    '''Returns mixed inputs, pairs of targets, and lambda'''
    if alpha > 0:
        lam = np.random.beta(alpha, alpha)
    else:
        lam = 0.001

    batch_size = x.size()[0]
    if use_cuda:
        index = torch.randperm(batch_size).cuda()
    else:
        index = torch.randperm(batch_size)

    mixed_x = lam * x + (1 - lam) * x[index, :]
    y_a, y_b = y, y[index]
    return mixed_x, y_a, y_b, lam


def mixup_criterion(criterion, pred, y_a, y_b, lam):
    return lam * criterion(pred, y_a) + (1 - lam) * criterion(pred, y_b)


def train_mixup(train_queue, model, criterion, optimizer):
  objs = AverageMeter()
  top1 = AverageMeter()
  model.train()
  use_cuda = torch.cuda.is_available()

  for step, (input, target) in enumerate(train_queue):
    #Mixup
    inputs, targets_a, targets_b, lam = mixup_data(input, target,
                                                       0., use_cuda)
    inputs, targets_a, targets_b = map(Variable, (inputs,
                                                      targets_a, targets_b))
    inputs, targets_a, targets_b = inputs.cuda(), targets_a.cuda(), targets_b.cuda()

    outputs = model(inputs)
    loss = mixup_criterion(criterion, outputs, targets_a, targets_b, lam)
#     train_loss += loss.item()
    _, predicted = torch.max(outputs.data, 1)
    correct = (lam * predicted.eq(targets_a.data).cpu().sum().float()
                + (1 - lam) * predicted.eq(targets_b.data).cpu().sum().float())

    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    n = input.size(0)
    objs.update(loss.item(), n)
    top1.update(correct, n)

    if step % 10 == 0:
      print('train {} {:.3f} {:.3f}'.format(step, objs.avg, top1.avg))

  return top1.avg, objs.avg

    
def train(train_queue, model, criterion, optimizer):
  objs = AverageMeter()
  top1 = AverageMeter()
  model.train()

  for step, (input, target) in enumerate(train_queue):
    input = Variable(input).cuda()
    target = Variable(target).cuda()

    optimizer.zero_grad()
    logits = model(input)
    loss = criterion(logits, target)
    loss.backward()
    optimizer.step()

    prec1 = accuracy(logits, target, topk=(1,))
    n = input.size(0)
    objs.update(loss.item(), n)
    top1.update(prec1[0].item(), n)

    if step % 10 == 0:
      print('train {} {:.3f} {:.3f}'.format(step, objs.avg, top1.avg))

  return top1.avg, objs.avg


def infer(valid_queue, model, criterion):
  objs = AverageMeter()
  top1 = AverageMeter()
  model.eval()
  with torch.no_grad():
      for step, (input, target) in enumerate(valid_queue):
        input = Variable(input).cuda()
        target = Variable(target).cuda()

        logits = model(input)
        loss = criterion(logits, target)

        prec1 = accuracy(logits, target, topk=(1,))
        n = input.size(0)
        objs.update(loss.item(), n)
        top1.update(prec1[0].item(), n)

        if step % 10 == 0:
          print('valid {} {:.3f} {:.3f}'.format(step, objs.avg, top1.avg))

  return top1.avg, objs.avg


class AverageMeter(object):

  def __init__(self):
    self.reset()

  def reset(self):
    self.avg = 0
    self.sum = 0
    self.cnt = 0

  def update(self, val, n=1):
    self.sum += val * n
    self.cnt += n
    self.avg = self.sum / self.cnt


def accuracy(output, target, topk=(1,)):
  maxk = max(topk)
  batch_size = target.size(0)

  _, pred = output.topk(maxk, 1, True, True)
  pred = pred.t()
  correct = pred.eq(target.view(1, -1).expand_as(pred))

  res = []
  for k in topk:
    correct_k = correct[:k].view(-1).float().sum(0)
    res.append(correct_k.mul_(100.0/batch_size))
  return res


class RandAugResnet(nn.Module):
    def __init__(self, model, transform, min_values, scale_values):
        super(RandAugResnet, self).__init__()
        self.model = model
        self.transform = transform
        self.device=torch.device('cuda') if torch.cuda.is_available() else torch.device("cpu")
        self.eval_transform = transforms.Compose([
            transforms.Normalize(min_values, scale_values),
            transforms.ToPILImage(),
            transforms.Resize((64,64)),
            transforms.ToTensor()
        ]) #32x32
        
    def forward(self, x):
        if self.training:
            xs = []
            for x_ in x:
                x_ = self.transform(x_)
                xs.append(x_)
            xs = torch.stack(xs)
            x = self.model(xs.to(self.device))
        else:
            xs = []
            for x_ in x:
                x_ = self.eval_transform(x_)
                xs.append(x_)
            xs = torch.stack(xs)
            x = self.model(xs.to(self.device))
        return x

class NAS:
    def __init__(self):
        pass

    def search(self, train_x, train_y, valid_x, valid_y, metadata):
        n_classes = metadata['n_classes']
        
        channels = train_x.shape[1]
        min_values = []
        scale_values = []
        if train_x.shape[2] > train_x.shape[3]:
            input_size = train_x.shape[2] + 4
        else:
            input_size = train_x.shape[3] + 4
        for i in range(channels):
            min_values.append(np.min(train_x[:,i,:,:]))
            scale_values.append((np.max(train_x[:,i,:,:])-min_values[-1]))

        transform = transforms.Compose([
            transforms.Normalize(min_values, scale_values),
            transforms.ToPILImage(),
            transforms.Resize((input_size,input_size)),
            transforms.ToTensor()
        ]) #32x32
    
        # Loading model
        model = ShakeResNet(32, 64, n_classes)
        model.c_in = nn.Conv2d(train_x.shape[1], model.in_chs[0], 3, padding=1)

        # Add RandAugment with N, M(hyperparameter)
        if input_size < 80:
            transform.transforms.insert(3, RandAugment(2, 3))
            model = RandAugResnet(model, transform, min_values, scale_values, input_size)
        
        return model


train_transform = transforms.Compose([
#     transforms.Resize((32,32)),
    transforms.ToTensor(),
    ])

valid_transform = transforms.Compose([
#     transforms.Resize((32,32)),
    transforms.ToTensor(),
    ])
    
train_data = torchvision.datasets.ImageFolder(root='./Linnaeus_5_6464/train', transform=train_transform)
valid_data = torchvision.datasets.ImageFolder(root='./Linnaeus_5_6464/test', transform=valid_transform)

channels = 3
min_values = []
scale_values = []

train_queue = torch.utils.data.DataLoader(
  train_data, batch_size=64, shuffle=True, pin_memory=True, num_workers=2)

valid_queue = torch.utils.data.DataLoader(
  valid_data, batch_size=64, shuffle=False, pin_memory=True, num_workers=2)




criterion = nn.CrossEntropyLoss()
criterion = criterion.cuda()

n_classes = 5

model = ShakeResNet(32, 64, n_classes)
model.c_in = nn.Conv2d(3, model.in_chs[0], 3, padding=1)

# model = torchvision.models.densenet121()
# model.features[0] = nn.Conv2d(3, 64, kernel_size=7, stride=1, padding=3, bias=False)
# model.classifier = nn.Linear(1024, n_classes)

#RandAug
# for i in range(channels):
#     tmp_min = 9999
#     tmp_max = 0
#     for (j, _) in train_queue:
#         if tmp_min > np.min(j.numpy()[:,i,:,:]):
#             tmp_min = np.min(j.numpy()[:,i,:,:])
#         if tmp_max < np.max(j.numpy()[:,i,:,:]):
#             tmp_max = np.max(j.numpy()[:,i,:,:])
#     min_values.append(tmp_min)
#     scale_values.append(tmp_max-min_values[-1])

# transform = transforms.Compose([
#             transforms.Normalize(min_values, scale_values),
#             transforms.ToPILImage(),
#             transforms.Resize((32,32)),
#             transforms.ToTensor()
#         ]) #32x32
# transform.transforms.insert(3, RandAugment(2, 3))
# model = RandAugResnet(model, transform, min_values, scale_values)


model = model.cuda()

optimizer = torch.optim.SGD(
  model.parameters(),
  0.1,
  momentum=0.9,
  weight_decay=3e-4,
  )

scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
        optimizer, 64)

for epoch in range(64):
    print('epoch {} lr {:.3f}'.format(epoch, scheduler.get_lr()[0]))

    train_acc, train_obj = train(train_queue, model, criterion, optimizer)
    print('train_acc {:.3f}'.format(train_acc))

    valid_acc, valid_obj = infer(valid_queue, model, criterion)
    print('valid_acc {:.3f}'.format(valid_acc))
    scheduler.step()
    
