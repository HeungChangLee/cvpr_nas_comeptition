import numpy as np
import torch
import torch.nn as nn
import torch.utils
import torch.nn.functional as F
import torchvision.datasets as dset
import torch.backends.cudnn as cudnn

from torch.autograd import Variable
from dnat.utils import AvgrageMeter, accuracy
from dnat.model_search import Network
from dnat.architect import Architect
from dnat.model import NetworkCIFAR
from dnat.genotypes import Genotype, PRIMITIVES
import time
from datetime import timedelta
import warnings
warnings.filterwarnings(action='ignore') 


class NAS:
    def __init__(self):
        pass
    
    def train(self, train_queue, valid_queue, model, architect, criterion, optimizer, lr, arch_train):
      objs = AvgrageMeter()
      top1 = AvgrageMeter()
      top5 = AvgrageMeter()

      for step, (input, target) in enumerate(train_queue):
        model.train()
        n = input.size(0)

        input = Variable(input, requires_grad=False).cuda()
        target = Variable(target, requires_grad=False).cuda()

        if arch_train:
            architect.step(input, target, input, target, lr, optimizer, unrolled=False)
            
        optimizer.zero_grad()
        logits = model(input)
        loss = criterion(logits, target)
#         if args.auxiliary:
#           loss_aux = criterion(logits_aux, target)
#           loss += args.auxiliary_weight*loss_aux
        loss.backward()
        nn.utils.clip_grad_norm(model.parameters(), 5)
        optimizer.step()

        prec1, prec5 = accuracy(logits, target, topk=(1, 5))
        objs.update(loss.item(), n)
        top1.update(prec1.item(), n)
        top5.update(prec5.item(), n)

        if step % 50 == 0:
          logging.info('train %03d %e %f %f', step, objs.avg, top1.avg, top5.avg)

      return top1.avg, objs.avg
    
    # given some input data, return the "best possible" architecture
    def search(self, train_x, train_y, valid_x, valid_y, metadata):
        n_classes = metadata['n_classes']
        batch_size = 128
        lr = 0.025 #metadata['lr']
        momentum = 0.9
        weight_decay = 3e-4
        arch_lr = 6e-4
        epochs = 20
        arch_train = True
        
#         input_genotype = Genotype(normal=[('none', 0), ('skip_connect', 1), ('none', 0), ('ori_conv_3x3', 2), ('none', 0), ('ori_conv_3x3', 3), ('skip_connect', 2), ('skip_connect', 4)], normal_concat=[5], reduce=[('none', 0), ('skip_connect', 1), ('none', 0), ('ori_conv_3x3', 2), ('none', 0), ('ori_conv_3x3', 3), ('skip_connect', 2), ('skip_connect', 4)], reduce_concat=[5]) #Resnet
        input_genotype = Genotype(normal=[('none', 0), ('ori_conv_1x1', 1), ('none', 0), ('sep_conv_3x3_mob', 2), ('none', 0), ('ori_conv_1x1', 3), ('skip_connect', 1), ('skip_connect', 4)], normal_concat=[5], reduce=[('none', 0), ('ori_conv_1x1', 1), ('none', 0), ('sep_conv_3x3_mob', 2), ('none', 0), ('ori_conv_1x1', 3), ('skip_connect', 1), ('skip_connect', 4)], reduce_concat=[5]) #MobilenetV2

        
        train_dataset = torch.utils.data.TensorDataset(torch.Tensor(train_x), torch.Tensor(train_y).long())
        valid_dataset = torch.utils.data.TensorDataset(torch.Tensor(valid_x), torch.Tensor(valid_y).long())
        
        train_queue = torch.utils.data.DataLoader(train_dataset, batch_size)#=batch_size*4)
        valid_queue = torch.utils.data.DataLoader(valid_dataset, batch_size)#=batch_size*4)

        criterion = nn.CrossEntropyLoss()
        criterion = criterion.cuda()
#         model = Network(input_channel_num=train_x.shape[1],
#                         C=8, 
#                         num_classes=n_classes, 
#                         layers=8, 
#                         criterion=criterion)
        model = Network(input_channel_num=train_x.shape[1], C=8, num_classes=n_classes, layers=8, auxiliary=False, genotype=input_genotype, criterion=criterion)
        model.drop_path_prob = 0.0
        model = model.cuda()
        
        
        optimizer = torch.optim.SGD(
          model.parameters(),
          lr,
          momentum=momentum,
          weight_decay=weight_decay)
        
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            optimizer, float(epochs), eta_min=0.001)
        
        architect = Architect(model, momentum, arch_lr, weight_decay)
        nas_start = time.time()
        for epoch in range(epochs):
            lr = scheduler.get_lr()[0]
            print ('epoch {} lr {}'.format(epoch, lr))

#             genotype = model.genotype()
            print ('genotype = {}'.format(input_genotype))

            #print(F.softmax(model.alphas_normal, dim=-1))
            #print(F.softmax(model.alphas_reduce, dim=-1))

            # training
            train_acc, train_obj = self.train(train_queue, valid_queue, model, architect, criterion, optimizer, lr, arch_train)
            
            print ('train_acc {}'.format(train_acc))
            scheduler.step()
            
            nas_end = time.time()
            print ('NAS elapsed: ', str(timedelta(seconds=(nas_end-nas_start))))
            
            print ('Current arch param')
            print(model.alphas_reduce)
            print(model.alphas_normal)
        
#         final_genotype = model.genotype()
#         del model
#         if train_x.shape[1] == 1:
#             final_model = NetworkCIFAR(train_x.shape[1], 8, n_classes, 9, False, final_genotype)
#         else:
#             final_model = NetworkCIFAR(train_x.shape[1], 16, n_classes, 9, False, final_genotype)
        
        model.transform_arch()
        arch_train = False
        
        return model
    
    
# load the exact data loaders that we'll use to load the data
from ingestion_program.nascomp.helpers import *

# load the exact retraining script we'll use to evaluate the found models
from ingestion_program.nascomp.torch_evaluator import *
# from ipywidgets import FloatProgress
# from ipywidgets import IntProgress

# if you want to use the real development data, download the public data and set data_dir appropriately
# data_dir = 'sample_data'
data_dir = 'data'


# find all the datasets in the given directory:
dataset_paths = get_dataset_paths(data_dir)
dataset_predictions = []
for path in dataset_paths:
    (train_x, train_y), (valid_x, valid_y), (test_x), metadata = load_datasets(path)
    print("=== {} {}".format(metadata['name'],"="*50))
    print("Train X shape:",train_x.shape)
    print("Train Y shape:",train_y.shape)
    print("Valid X shape:",valid_x.shape)
    print("Valid Y shape:",valid_y.shape)
    print("Test X shape:", test_x.shape)
    print("Metadata:", metadata)
    

    # initialize our NAS class
    nas = NAS()
    
    # search for a model
    model = nas.search(train_x, train_y, valid_x, valid_y, metadata)
    
    # package data for the evaluator
    data = (train_x, train_y), (valid_x, valid_y), test_x
    
    # retrain the model from scratch
    results = torch_evaluator(model, data, metadata, n_epochs=64, full_train=True)
    
    # clean up the NAS class
    del nas
    
    # save our predictions
    dataset_predictions.append(results['test_predictions'])
#     print(dataset_predictions)


overall_score = 0
out = []
for i, path in enumerate(dataset_paths):

    # load the reference values
    ref_y = np.load(os.path.join(path, 'test_y.npy'))

    # load the dataset_metadata for this dataset
    metadata =  load_dataset_metadata(path)
    
    print("=== Scoring {} ===".format(metadata['name']))
    index = metadata['name'][-1]

    # load the model predictions
    pred_y = dataset_predictions[i]

    # compute accuracy
    score = sum(ref_y == pred_y)/float(len(ref_y)) * 100
    print("  Raw score:", score)
    print("  Benchmark:", metadata['benchmark'])

    # adjust score according to benchmark
    point_weighting = 10/(100 - metadata['benchmark'])
    score -= metadata['benchmark']
    score *= point_weighting
    print("  Adjusted:  ", score)

    # add per-dataset score to overall
    overall_score += score

    # add to scoring stringg
    out.append("Dataset_{}_Score: {:.3f}".format(index, score))
out.append("Overall_Score: {:.3f}".format(overall_score))

# print score
print(out)