# from efficientnet_pytorch import EfficientNet
import torch.nn as nn
import torchvision
from functools import partial
from torchvision.models.mobilenetv2 import ConvBNActivation
# from resnet_arch import resnet18

class NAS:
    def __init__(self):
        pass
    
    def search(self, train_x, train_y, valid_x, valid_y, metadata):
        n_classes = metadata['n_classes']
#         model = EfficientNet.from_pretrained('efficientnet-b1', in_channels=train_x.shape[1], num_classes=n_classes)
#         model = EfficientNet.from_name('efficientnet-b5', in_channels=train_x.shape[1], num_classes=n_classes)

        # ResNet 18
        model = torchvision.models.resnet18()
        model.conv1 = nn.Conv2d(train_x.shape[1], 64, kernel_size=(7, 7), stride=1, padding=3)
        model.fc = nn.Linear(model.fc.in_features, n_classes, bias=True)

#         ## Local ResNet 18
#         model = resnet18()
#         model.conv1 = nn.Conv2d(train_x.shape[1], 64, kernel_size=(7, 7), stride=1, padding=3)
#         model.fc = nn.Linear(model.fc.in_features, n_classes, bias=True)
        
        ## MobileNet V2
#         model = torchvision.models.mobilenet_v2()
#         norm_layer = nn.BatchNorm2d
#         model.features[0] = ConvBNActivation(train_x.shape[1], 32, stride=2, norm_layer=norm_layer)
#         model.classifier = nn.Sequential(
#             nn.Dropout(0.2),
#             nn.Linear(1280, n_classes),
#         )
        
        ## MobileNet V3 Large
#         model = torchvision.models.mobilenet_v3_large()
#         norm_layer = partial(nn.BatchNorm2d, eps=0.001, momentum=0.01)
#         model.features[0] = ConvBNActivation(64, 16, kernel_size=3, stride=2, norm_layer=norm_layer,
#                                        activation_layer=nn.Hardswish)
#         model.classifier = nn.Sequential(
#             nn.Linear(960, 1280),
#             nn.Hardswish(inplace=True),
#             nn.Dropout(p=0.2, inplace=True),
#             nn.Linear(1280, n_classes),
#         )
#         model = nn.Sequential(
#             nn.Conv2d(train_x.shape[1], 64, kernel_size=(7, 7), stride=1, padding=3),
#             norm_layer(64),
#             nn.ReLU(inplace=True),
#             model
#         )
        
        ## MobileNet V3 Small
#         model = torchvision.models.mobilenet_v3_small()
#         norm_layer = partial(nn.BatchNorm2d, eps=0.001, momentum=0.01)
#         model.features[0] = ConvBNActivation(train_x.shape[1], 16, kernel_size=3, stride=2, norm_layer=norm_layer,
#                                        activation_layer=nn.Hardswish)
#         model.classifier = nn.Sequential(
#             nn.Linear(576, 1024),
#             nn.Hardswish(inplace=True),
#             nn.Dropout(p=0.2, inplace=True),
#             nn.Linear(1024, n_classes),
#         )

        ## DenseNet
#         model = torchvision.models.densenet121()
#         model.features[0] = nn.Conv2d(train_x.shape[1], 64, kernel_size=7, stride=1, padding=3, bias=False)
#         model.classifier = nn.Linear(1024, n_classes)

#         model = torchvision.models.densenet201()
#         model.features[0] = nn.Conv2d(train_x.shape[1], 64, kernel_size=7, stride=1, padding=3, bias=False)
#         model.classifier = nn.Linear(1920, n_classes)
        
        ## resnext50_32x4d
#         model = torchvision.models.resnext50_32x4d()
#         model = torchvision.models.resnext101_32x8d()
#         model = torchvision.models.wide_resnet50_2()
#         model.conv1 = nn.Conv2d(train_x.shape[1], 64, kernel_size=(7, 7), stride=1, padding=3)
#         model.fc = nn.Linear(model.fc.in_features, n_classes, bias=True)

        
        return model
        
        
# load the exact data loaders that we'll use to load the data
from ingestion_program.nascomp.helpers import *

# load the exact retraining script we'll use to evaluate the found models
from ingestion_program.nascomp.torch_evaluator import *
# from ipywidgets import FloatProgress
# from ipywidgets import IntProgress

# if you want to use the real development data, download the public data and set data_dir appropriately
# data_dir = 'sample_data'
data_dir = 'data'


# find all the datasets in the given directory:
dataset_paths = get_dataset_paths(data_dir)
dataset_predictions = []
for path in dataset_paths:
    (train_x, train_y), (valid_x, valid_y), (test_x), metadata = load_datasets(path)
    print("=== {} {}".format(metadata['name'],"="*50))
    print("Train X shape:",train_x.shape)
    print("Train Y shape:",train_y.shape)
    print("Valid X shape:",valid_x.shape)
    print("Valid Y shape:",valid_y.shape)
    print("Test X shape:", test_x.shape)
    print("Metadata:", metadata)
    

    # initialize our NAS class
    nas = NAS()
    
    # search for a model
    model = nas.search(train_x, train_y, valid_x, valid_y, metadata)
    
    # package data for the evaluator
    data = (train_x, train_y), (valid_x, valid_y), test_x
    
    # retrain the model from scratch
    results = torch_evaluator(model, data, metadata, n_epochs=64, full_train=True)
    
    # clean up the NAS class
    del nas
    
    # save our predictions
    dataset_predictions.append(results['test_predictions'])
#     print(dataset_predictions)


overall_score = 0
out = []
for i, path in enumerate(dataset_paths):

    # load the reference values
    ref_y = np.load(os.path.join(path, 'test_y.npy'))

    # load the dataset_metadata for this dataset
    metadata =  load_dataset_metadata(path)
    
    print("=== Scoring {} ===".format(metadata['name']))
    index = metadata['name'][-1]

    # load the model predictions
    pred_y = dataset_predictions[i]

    # compute accuracy
    score = sum(ref_y == pred_y)/float(len(ref_y)) * 100
    print("  Raw score:", score)
    print("  Benchmark:", metadata['benchmark'])

    # adjust score according to benchmark
    point_weighting = 10/(100 - metadata['benchmark'])
    score -= metadata['benchmark']
    score *= point_weighting
    print("  Adjusted:  ", score)

    # add per-dataset score to overall
    overall_score += score

    # add to scoring stringg
    out.append("Dataset_{}_Score: {:.3f}".format(index, score))
out.append("Overall_Score: {:.3f}".format(overall_score))

# print score
print(out)